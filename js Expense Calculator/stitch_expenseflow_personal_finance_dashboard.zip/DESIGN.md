---
name: Kinetic Precision
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#515f77'
  on-secondary: '#ffffff'
  secondary-container: '#d2e0fd'
  on-secondary-container: '#55637c'
  tertiary: '#7e3000'
  on-tertiary: '#ffffff'
  tertiary-container: '#a44100'
  on-tertiary-container: '#ffd2be'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#d5e3ff'
  secondary-fixed-dim: '#b9c7e3'
  on-secondary-fixed: '#0d1c31'
  on-secondary-fixed-variant: '#39475e'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb695'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 24px
  margin-mobile: 16px
  container-max: 1440px
---

## Brand & Style

The design system is engineered for a modern fintech environment, prioritizing clarity, trust, and rapid information processing. The brand personality is professional yet technologically forward-leaning, aimed at finance teams and SaaS operators who require precision without the cognitive load of traditional banking software.

The visual style is **Corporate / Modern** with a lean toward **Minimalism**. It utilizes expansive white space in light mode and deep, layered depth in dark mode to create a hierarchical structure. Elements are defined by subtle borders and soft shadows rather than aggressive color blocks, ensuring that the user’s focus remains entirely on financial data and actionable insights.

## Colors

The palette is anchored by a vibrant Indigo primary color, used strategically for "North Star" actions and data highlights. 

**Light Mode**
- Primary surfaces use a pure white (#FFFFFF) to maximize contrast.
- Typography follows a strict hierarchy: Dark Navy (#0F172A) for headers and Slate Grey (#64728B) for supportive text.
- Borders use a faint grey (#E2E8F0) to define structure without adding visual noise.

**Dark Mode**
- The canvas shifts to Deep Navy (#0F172A).
- Component surfaces use a slightly lifted Slate (#1E293B) to create natural depth.
- Borders are darkened to a subtle slate to maintain a cohesive, low-glare environment.

## Typography

This design system utilizes **Inter** for all UI and editorial content due to its exceptional legibility and neutral, systematic tone. A secondary typeface, **JetBrains Mono**, is introduced specifically for tabular data, transaction IDs, and currency amounts to ensure character alignment and a "fintech-native" aesthetic.

Headlines should use tighter letter spacing to maintain a compact, high-end feel. All body text defaults to 16px for optimal accessibility, while labels and metadata utilize 14px or 12px with slightly increased weight to ensure visibility.

## Layout & Spacing

The layout is built on a rigorous **8px grid system**. This rhythm dictates all padding, margins, and component heights, ensuring a mathematical harmony across the interface.

- **Grid System**: Use a 12-column fluid grid for desktop layouts with 24px gutters. For dashboards, use a fixed sidebar (280px) with a fluid content area.
- **Responsive Behavior**: On tablets, the sidebar collapses into a hamburger menu or icon-only rail. On mobile, margins reduce to 16px, and all 2-column card layouts stack vertically.
- **Vertical Rhythm**: Maintain consistent spacing between sections using the 'xl' (32px) token to prevent the dense financial data from feeling overwhelming.

## Elevation & Depth

Visual hierarchy is achieved through a combination of **Tonal Layers** and **Ambient Shadows**.

1.  **Level 0 (Background)**: The base canvas.
2.  **Level 1 (Cards/Containers)**: Background color with a 1px border. In light mode, a very soft, diffused shadow (Blur: 12px, Y: 4px, Opacity: 4%) is applied to give the impression of a slight lift.
3.  **Level 2 (Modals/Popovers)**: Elevated surfaces with a more pronounced shadow (Blur: 24px, Y: 8px, Opacity: 8%) to draw focus and indicate interactivity.

Avoid heavy black shadows; instead, tint shadows with the neutral color (#0F172A) to keep them feeling integrated and modern.

## Shapes

The design system adopts a **Rounded** shape language to soften the analytical nature of the data. 

- **Components (Buttons, Inputs, Small Cards)**: 0.5rem (8px) radius.
- **Large Containers (Dashboard Cards, Sidebars)**: 1rem (16px) radius.
- **Interactive Elements (Search bars)**: Can utilize the `rounded-xl` (1.5rem) token for a more approachable, modern feel.

This consistent rounding creates a friendly, approachable environment that counterbalances the "serious" nature of fintech.

## Components

### Buttons
- **Primary**: Solid Indigo (#4F46E5) with white text. High-contrast, 0.5rem corner radius.
- **Secondary**: Light mode uses a faint grey fill (#F1F5F9); Dark mode uses a transparent stroke.
- **States**: Hover states should involve a slight darkening of the fill (Primary) or a subtle background tint (Ghost/Secondary).

### Cards
Cards are the primary vessel for data. They must feature a 1px border (#E2E8F0 in light, #334155 in dark) and 24px internal padding. Title areas should be separated by a faint horizontal divider when the card contains complex lists.

### Input Fields
Inputs should have a height of 40px or 48px. Use a 1px border that shifts to the Indigo primary color on focus. Labels should always be visible above the field, never solely as placeholders.

### Chips & Status Indicators
- **Success**: Emerald green background with dark green text.
- **Warning**: Amber background with dark brown text.
- **Neutral**: Slate background with slate text.
Chips use a pill-shape (32px radius) to distinguish them from actionable buttons.

### Lists & Tables
Finance data should utilize a "Zebra" striping or subtle horizontal dividers. Row height should be 56px for standard density and 48px for high density. Monospaced font (JetBrains Mono) is preferred for all numeric values within tables.